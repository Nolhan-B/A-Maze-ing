from .generator import MazeGenerator

__all__ = ["MazeGenerator"]
